from flask import Blueprint, render_template, request, redirect, url_for, flash, session, send_file, abort
from src.models.models import db, User, Order, OrderDetail, Product
from src.routes.auth import login_required
from datetime import datetime
import os
import secrets
import hashlib

user_bp = Blueprint('user', __name__)

@user_bp.route('/my-account')
@login_required
def my_account():
    user = User.query.get(session['user_id'])
    return render_template('user/my_account.html', user=user)

@user_bp.route('/my-purchases')
@login_required
def my_purchases():
    # Get all completed orders for the user
    orders = Order.query.filter_by(
        user_id=session['user_id'],
        payment_status='completed'
    ).order_by(Order.created_at.desc()).all()
    
    return render_template('user/my_purchases.html', orders=orders)

@user_bp.route('/my-purchases/order/<int:order_id>')
@login_required
def order_detail(order_id):
    # Get order and verify it belongs to the current user
    order = Order.query.filter_by(
        id=order_id,
        user_id=session['user_id']
    ).first_or_404()
    
    return render_template('user/order_detail.html', order=order)

@user_bp.route('/download/<int:order_detail_id>')
@login_required
def download_product(order_detail_id):
    # Get order detail and verify it belongs to the current user
    order_detail = OrderDetail.query.join(Order).filter(
        OrderDetail.id == order_detail_id,
        Order.user_id == session['user_id'],
        Order.payment_status == 'completed'
    ).first_or_404()
    
    # Check if download is still valid
    if order_detail.download_expiry and datetime.utcnow() > order_detail.download_expiry:
        flash('انتهت صلاحية التنزيل. يرجى التواصل مع الدعم للمساعدة', 'danger')
        return redirect(url_for('user.my_purchases'))
    
    # Get product
    product = Product.query.get(order_detail.product_id)
    if not product or not product.file_path:
        flash('الملف غير متوفر للتنزيل', 'danger')
        return redirect(url_for('user.my_purchases'))
    
    # Update download count
    order_detail.download_count += 1
    order_detail.download_status = 'downloaded'
    product.download_count += 1
    db.session.commit()
    
    # Generate a secure download token
    token = secrets.token_hex(16)
    session[f'download_token_{order_detail_id}'] = token
    
    # Redirect to secure download route with token
    return redirect(url_for('user.secure_download', 
                           order_detail_id=order_detail_id, 
                           token=token))

@user_bp.route('/secure-download/<int:order_detail_id>/<token>')
@login_required
def secure_download(order_detail_id, token):
    # Verify token
    if session.get(f'download_token_{order_detail_id}') != token:
        abort(403)
    
    # Get order detail
    order_detail = OrderDetail.query.get_or_404(order_detail_id)
    product = Product.query.get_or_404(order_detail.product_id)
    
    # Clear token after use
    del session[f'download_token_{order_detail_id}']
    session.modified = True
    
    # Get file path
    file_path = os.path.join('src', product.file_path)
    if not os.path.exists(file_path):
        flash('الملف غير متوفر للتنزيل', 'danger')
        return redirect(url_for('user.my_purchases'))
    
    # Generate a unique filename for the download
    original_filename = os.path.basename(product.file_path)
    filename_parts = os.path.splitext(original_filename)
    unique_filename = f"{filename_parts[0]}_{hashlib.md5(str(order_detail.id).encode()).hexdigest()[:8]}{filename_parts[1]}"
    
    # Send file for download
    return send_file(file_path, 
                    as_attachment=True, 
                    download_name=unique_filename)

@user_bp.route('/my-loyalty-points')
@login_required
def my_loyalty_points():
    user = User.query.get(session['user_id'])
    
    # Get orders with loyalty points
    orders_with_points = Order.query.filter(
        Order.user_id == session['user_id'],
        Order.payment_status == 'completed',
        Order.loyalty_points_earned > 0
    ).order_by(Order.created_at.desc()).all()
    
    # Calculate points value
    points_value = user.loyalty_points * 0.01  # Example: 1 point = $0.01
    
    return render_template('user/my_loyalty_points.html', 
                          user=user, 
                          orders=orders_with_points,
                          points_value=points_value)

@user_bp.route('/my-reviews')
@login_required
def my_reviews():
    # Get all reviews by the user
    user = User.query.get(session['user_id'])
    
    return render_template('user/my_reviews.html', user=user)
