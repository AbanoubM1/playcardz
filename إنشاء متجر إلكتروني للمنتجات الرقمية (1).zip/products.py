from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from src.models.models import db, Product, Category, Review
from src.routes.auth import login_required
import os
from werkzeug.utils import secure_filename
from datetime import datetime

products_bp = Blueprint('products', __name__)

@products_bp.route('/products')
def all_products():
    page = request.args.get('page', 1, type=int)
    per_page = 12
    
    # Get filter parameters
    category_id = request.args.get('category', type=int)
    sort_by = request.args.get('sort', 'newest')
    search_query = request.args.get('q')
    
    # Base query
    query = Product.query.filter_by(is_active=True)
    
    # Apply filters
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if search_query:
        query = query.filter(Product.name.ilike(f'%{search_query}%') | 
                            Product.description.ilike(f'%{search_query}%'))
    
    # Apply sorting
    if sort_by == 'price_low':
        query = query.order_by(Product.price.asc())
    elif sort_by == 'price_high':
        query = query.order_by(Product.price.desc())
    elif sort_by == 'popular':
        query = query.order_by(Product.download_count.desc())
    else:  # newest
        query = query.order_by(Product.created_at.desc())
    
    # Paginate results
    products = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Get all categories for filter sidebar
    categories = Category.query.all()
    
    return render_template('products/all_products.html', 
                          products=products,
                          categories=categories,
                          current_category=category_id,
                          current_sort=sort_by,
                          search_query=search_query)

@products_bp.route('/products/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    
    # Get related products from same category
    related_products = Product.query.filter(
        Product.category_id == product.category_id,
        Product.id != product.id,
        Product.is_active == True
    ).limit(4).all()
    
    # Get approved reviews
    reviews = Review.query.filter_by(product_id=product_id, is_approved=True).all()
    
    # Calculate average rating
    avg_rating = 0
    if reviews:
        avg_rating = sum(review.rating for review in reviews) / len(reviews)
    
    return render_template('products/product_detail.html', 
                          product=product,
                          related_products=related_products,
                          reviews=reviews,
                          avg_rating=avg_rating)

@products_bp.route('/products/category/<int:category_id>')
def products_by_category(category_id):
    category = Category.query.get_or_404(category_id)
    
    # Redirect to all products with category filter
    return redirect(url_for('products.all_products', category=category_id))

@products_bp.route('/products/<int:product_id>/review', methods=['POST'])
@login_required
def add_review(product_id):
    product = Product.query.get_or_404(product_id)
    
    rating = request.form.get('rating', type=int)
    comment = request.form.get('comment')
    
    if not rating or rating < 1 or rating > 5:
        flash('يرجى تقديم تقييم صالح (1-5)', 'danger')
        return redirect(url_for('products.product_detail', product_id=product_id))
    
    # Check if user has purchased the product
    # This would typically check order history
    # For now, we'll allow any logged-in user to review
    
    # Check if user already reviewed this product
    existing_review = Review.query.filter_by(
        product_id=product_id,
        user_id=session['user_id']
    ).first()
    
    if existing_review:
        # Update existing review
        existing_review.rating = rating
        existing_review.comment = comment
        existing_review.created_at = datetime.utcnow()
        flash('تم تحديث مراجعتك بنجاح', 'success')
    else:
        # Create new review
        new_review = Review(
            product_id=product_id,
            user_id=session['user_id'],
            rating=rating,
            comment=comment,
            created_at=datetime.utcnow(),
            is_approved=False  # Requires admin approval
        )
        db.session.add(new_review)
        flash('تم إرسال مراجعتك بنجاح وهي قيد المراجعة', 'success')
    
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash('حدث خطأ أثناء حفظ المراجعة', 'danger')
    
    return redirect(url_for('products.product_detail', product_id=product_id))

@products_bp.route('/search')
def search():
    query = request.args.get('q', '')
    if not query:
        return redirect(url_for('products.all_products'))
    
    # Redirect to all products with search parameter
    return redirect(url_for('products.all_products', q=query))

@products_bp.route('/api/products')
def api_products():
    """API endpoint for products (for AJAX requests)"""
    products = Product.query.filter_by(is_active=True).all()
    return jsonify([product.to_dict() for product in products])

@products_bp.route('/api/products/<int:product_id>')
def api_product_detail(product_id):
    """API endpoint for single product (for AJAX requests)"""
    product = Product.query.get_or_404(product_id)
    return jsonify(product.to_dict())
