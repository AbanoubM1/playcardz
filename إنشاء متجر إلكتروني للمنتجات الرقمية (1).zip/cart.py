from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from src.models.models import db, Product, Order, OrderDetail, Discount, User
from src.routes.auth import login_required
from datetime import datetime, timedelta
import json
import secrets

cart_bp = Blueprint('cart', __name__)

@cart_bp.route('/cart')
def view_cart():
    # Get cart from session
    cart = session.get('cart', {})
    cart_items = []
    total = 0
    
    # Get product details for each item in cart
    for product_id, quantity in cart.items():
        product = Product.query.get(int(product_id))
        if product and product.is_active:
            item_total = product.price * quantity
            cart_items.append({
                'product': product,
                'quantity': quantity,
                'total': item_total
            })
            total += item_total
    
    return render_template('cart/cart.html', cart_items=cart_items, total=total)

@cart_bp.route('/cart/add/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    product = Product.query.get_or_404(product_id)
    
    # Initialize cart if not exists
    if 'cart' not in session:
        session['cart'] = {}
    
    # Add product to cart (digital products typically have quantity=1)
    session['cart'][str(product_id)] = 1
    session.modified = True
    
    flash(f'تمت إضافة {product.name} إلى سلة التسوق', 'success')
    
    # Redirect based on request
    if request.form.get('redirect_to_cart'):
        return redirect(url_for('cart.view_cart'))
    return redirect(url_for('products.product_detail', product_id=product_id))

@cart_bp.route('/cart/remove/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    if 'cart' in session and str(product_id) in session['cart']:
        del session['cart'][str(product_id)]
        session.modified = True
        flash('تم إزالة المنتج من سلة التسوق', 'success')
    
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/cart/clear', methods=['POST'])
def clear_cart():
    session['cart'] = {}
    session.modified = True
    flash('تم تفريغ سلة التسوق', 'success')
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/cart/apply-discount', methods=['POST'])
def apply_discount():
    discount_code = request.form.get('discount_code')
    
    if not discount_code:
        flash('يرجى إدخال رمز الخصم', 'warning')
        return redirect(url_for('cart.view_cart'))
    
    # Find discount in database
    discount = Discount.query.filter_by(code=discount_code, is_active=True).first()
    
    if not discount:
        flash('رمز الخصم غير صالح', 'danger')
        return redirect(url_for('cart.view_cart'))
    
    # Check if discount is valid (dates, usage limits)
    now = datetime.utcnow()
    if now < discount.start_date or now > discount.end_date:
        flash('رمز الخصم منتهي الصلاحية', 'danger')
        return redirect(url_for('cart.view_cart'))
    
    if discount.max_uses and discount.current_uses >= discount.max_uses:
        flash('تم استخدام رمز الخصم الحد الأقصى من المرات', 'danger')
        return redirect(url_for('cart.view_cart'))
    
    # Calculate cart total
    cart = session.get('cart', {})
    total = 0
    for product_id, quantity in cart.items():
        product = Product.query.get(int(product_id))
        if product and product.is_active:
            total += product.price * quantity
    
    # Check minimum purchase requirement
    if total < discount.min_purchase:
        flash(f'الحد الأدنى للشراء لاستخدام هذا الخصم هو {discount.min_purchase}', 'danger')
        return redirect(url_for('cart.view_cart'))
    
    # Store discount in session
    session['discount'] = {
        'id': discount.id,
        'code': discount.code,
        'type': discount.type,
        'value': discount.value
    }
    session.modified = True
    
    flash('تم تطبيق رمز الخصم بنجاح', 'success')
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/cart/remove-discount', methods=['POST'])
def remove_discount():
    if 'discount' in session:
        del session['discount']
        session.modified = True
        flash('تم إزالة الخصم', 'success')
    
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    # Get cart from session
    cart = session.get('cart', {})
    
    if not cart:
        flash('سلة التسوق فارغة', 'warning')
        return redirect(url_for('cart.view_cart'))
    
    # Get user
    user = User.query.get(session['user_id'])
    
    # Calculate totals
    cart_items = []
    subtotal = 0
    
    for product_id, quantity in cart.items():
        product = Product.query.get(int(product_id))
        if product and product.is_active:
            item_total = product.price * quantity
            cart_items.append({
                'product': product,
                'quantity': quantity,
                'total': item_total
            })
            subtotal += item_total
    
    # Apply discount if any
    discount_amount = 0
    if 'discount' in session:
        discount = session['discount']
        if discount['type'] == 'percentage':
            discount_amount = subtotal * (discount['value'] / 100)
        else:  # fixed amount
            discount_amount = discount['value']
    
    # Calculate loyalty points that can be used
    available_points = user.loyalty_points
    points_value = available_points * 0.01  # Example: 1 point = $0.01
    
    # Get applied loyalty points from form
    used_points = 0
    points_discount = 0
    
    if request.method == 'POST':
        used_points = request.form.get('use_loyalty_points', type=int, default=0)
        if used_points > available_points:
            used_points = available_points
        
        points_discount = used_points * 0.01
    
    # Calculate final total
    total = subtotal - discount_amount - points_discount
    if total < 0:
        total = 0
    
    # Calculate loyalty points to be earned (1 point per $1 spent)
    points_to_earn = int(total)
    
    if request.method == 'POST':
        payment_method = request.form.get('payment_method')
        
        # Create order
        new_order = Order(
            user_id=user.id,
            total_amount=total,
            payment_status='pending',
            payment_method=payment_method,
            created_at=datetime.utcnow(),
            discount_applied=discount_amount,
            loyalty_points_used=used_points,
            loyalty_points_earned=points_to_earn
        )
        
        db.session.add(new_order)
        db.session.flush()  # Get order ID without committing
        
        # Create order details
        for product_id, quantity in cart.items():
            product = Product.query.get(int(product_id))
            if product and product.is_active:
                order_detail = OrderDetail(
                    order_id=new_order.id,
                    product_id=product.id,
                    price=product.price,
                    download_status='not_downloaded',
                    download_count=0,
                    download_expiry=datetime.utcnow() + timedelta(days=30)  # 30 days download window
                )
                db.session.add(order_detail)
        
        # Update discount usage if applicable
        if 'discount' in session:
            discount_obj = Discount.query.get(session['discount']['id'])
            if discount_obj:
                discount_obj.current_uses += 1
        
        # Update user loyalty points
        user.loyalty_points = user.loyalty_points - used_points + points_to_earn
        
        try:
            db.session.commit()
            
            # Clear cart and discount after successful order
            session['cart'] = {}
            if 'discount' in session:
                del session['discount']
            session.modified = True
            
            # For demo purposes, automatically mark payment as completed
            # In a real application, this would be handled by payment gateway callback
            new_order.payment_status = 'completed'
            new_order.payment_id = f'DEMO-{secrets.token_hex(6)}'
            db.session.commit()
            
            flash('تم إنشاء الطلب بنجاح!', 'success')
            return redirect(url_for('user.order_detail', order_id=new_order.id))
        except Exception as e:
            db.session.rollback()
            flash(f'حدث خطأ أثناء إنشاء الطلب: {str(e)}', 'danger')
    
    return render_template('cart/checkout.html',
                          cart_items=cart_items,
                          subtotal=subtotal,
                          discount_amount=discount_amount,
                          available_points=available_points,
                          points_value=points_value,
                          total=total,
                          points_to_earn=points_to_earn)
