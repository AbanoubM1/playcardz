// Main JavaScript for Digital Store

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });
    
    // Flash message auto-dismiss
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Product image preview functionality
    var previewImages = document.querySelectorAll('.preview-image');
    var mainImage = document.getElementById('main-product-image');
    
    if (previewImages.length > 0 && mainImage) {
        previewImages.forEach(function(img) {
            img.addEventListener('click', function() {
                mainImage.src = this.src;
            });
        });
    }
    
    // Discount code form validation
    var discountForm = document.getElementById('discount-form');
    if (discountForm) {
        discountForm.addEventListener('submit', function(event) {
            var discountCode = document.getElementById('discount_code').value;
            if (!discountCode.trim()) {
                event.preventDefault();
                alert('الرجاء إدخال رمز الخصم');
            }
        });
    }
    
    // Password confirmation validation
    var passwordForm = document.getElementById('password-form');
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(event) {
            var password = document.getElementById('new_password').value;
            var confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                event.preventDefault();
                alert('كلمات المرور غير متطابقة');
            }
        });
    }
    
    // Cart quantity update
    var quantityInputs = document.querySelectorAll('.quantity-input');
    if (quantityInputs.length > 0) {
        quantityInputs.forEach(function(input) {
            input.addEventListener('change', function() {
                var form = this.closest('form');
                form.submit();
            });
        });
    }
    
    // Loyalty points toggle
    var loyaltyCheckbox = document.getElementById('use_loyalty_points');
    if (loyaltyCheckbox) {
        loyaltyCheckbox.addEventListener('change', function() {
            var form = this.closest('form');
            form.submit();
        });
    }
    
    // Payment method toggle
    var paymentMethods = document.querySelectorAll('input[name="payment_method"]');
    var creditCardForm = document.getElementById('credit-card-form');
    
    if (paymentMethods.length > 0 && creditCardForm) {
        paymentMethods.forEach(function(method) {
            method.addEventListener('change', function() {
                if (this.value === 'credit_card') {
                    creditCardForm.style.display = 'block';
                } else {
                    creditCardForm.style.display = 'none';
                }
            });
        });
    }
    
    // Search form validation
    var searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(event) {
            var searchInput = document.getElementById('search-input').value;
            if (!searchInput.trim()) {
                event.preventDefault();
            }
        });
    }
    
    // Add animation to elements when they come into view
    var animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    if (animatedElements.length > 0) {
        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        });
        
        animatedElements.forEach(function(element) {
            observer.observe(element);
        });
    }
});
