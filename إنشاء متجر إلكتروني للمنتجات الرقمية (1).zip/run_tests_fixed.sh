#!/bin/bash

# Script to test the digital store functionality

echo "=== Starting Digital Store Testing ==="
echo "Testing environment: Development"
echo "Date: $(date)"
echo ""

# Create test directory
mkdir -p /home/ubuntu/digital_store_project/test_results

# Activate virtual environment
source /home/ubuntu/digital_store/venv/bin/activate

# Test database connection
echo "Testing database connection..."
cd /home/ubuntu/digital_store
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db
from flask import Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        connection = db.engine.connect()
        print('Database connection successful')
        connection.close()
    except Exception as e:
        print(f'Database connection failed: {e}')
"
echo "Database connection test complete"
echo ""

# Test user registration and authentication
echo "Testing user authentication..."
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, User
from flask import Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Test user creation
        test_user = User.query.filter_by(email='test@example.com').first()
        if test_user:
            db.session.delete(test_user)
            db.session.commit()
            
        new_user = User(
            username='testuser',
            email='test@example.com',
            first_name='Test',
            last_name='User',
            is_active=True
        )
        new_user.set_password('password123')
        db.session.add(new_user)
        db.session.commit()
        print('User creation successful')
        
        # Test password verification
        user = User.query.filter_by(email='test@example.com').first()
        if user.check_password('password123'):
            print('Password verification successful')
        else:
            print('Password verification failed')
            
        # Clean up
        db.session.delete(user)
        db.session.commit()
    except Exception as e:
        print(f'User authentication test failed: {e}')
"
echo "User authentication test complete"
echo ""

# Test product management
echo "Testing product management..."
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, Product, Category
from flask import Flask
import json
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Create test category
        test_category = Category.query.filter_by(name='Test Category').first()
        if not test_category:
            test_category = Category(name='Test Category', description='Test Category Description')
            db.session.add(test_category)
            db.session.commit()
        
        # Create test product
        test_product = Product.query.filter_by(name='Test Product').first()
        if test_product:
            db.session.delete(test_product)
            db.session.commit()
            
        new_product = Product(
            name='Test Product',
            description='Test Product Description',
            price=9.99,
            category_id=test_category.id,
            is_active=True,
            file_path='static/uploads/test.txt',
            file_size=1024,
            file_type='txt',
            preview_images=json.dumps(['static/uploads/preview.jpg'])
        )
        db.session.add(new_product)
        db.session.commit()
        print('Product creation successful')
        
        # Test product retrieval
        product = Product.query.filter_by(name='Test Product').first()
        if product and product.price == 9.99:
            print('Product retrieval successful')
        else:
            print('Product retrieval failed')
            
        # Clean up
        db.session.delete(product)
        db.session.commit()
    except Exception as e:
        print(f'Product management test failed: {e}')
"
echo "Product management test complete"
echo ""

# Test order and payment system
echo "Testing order and payment system..."
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, User, Product, Category, Order, OrderDetail
from flask import Flask
from datetime import datetime, timedelta
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Create test user
        test_user = User.query.filter_by(email='test@example.com').first()
        if not test_user:
            test_user = User(
                username='testuser',
                email='test@example.com',
                first_name='Test',
                last_name='User',
                is_active=True
            )
            test_user.set_password('password123')
            db.session.add(test_user)
            db.session.commit()
        
        # Create test category
        test_category = Category.query.filter_by(name='Test Category').first()
        if not test_category:
            test_category = Category(name='Test Category', description='Test Category Description')
            db.session.add(test_category)
            db.session.commit()
        
        # Create test product
        test_product = Product.query.filter_by(name='Test Product').first()
        if not test_product:
            test_product = Product(
                name='Test Product',
                description='Test Product Description',
                price=9.99,
                category_id=test_category.id,
                is_active=True,
                file_path='static/uploads/test.txt',
                file_size=1024,
                file_type='txt'
            )
            db.session.add(test_product)
            db.session.commit()
        
        # Create test order
        test_order = Order(
            user_id=test_user.id,
            total_amount=9.99,
            payment_status='completed',
            payment_method='credit_card',
            payment_id='TEST123',
            created_at=datetime.utcnow(),
            discount_applied=0,
            loyalty_points_used=0,
            loyalty_points_earned=10
        )
        db.session.add(test_order)
        db.session.flush()
        
        # Create test order detail
        test_order_detail = OrderDetail(
            order_id=test_order.id,
            product_id=test_product.id,
            price=9.99,
            download_status='not_downloaded',
            download_count=0,
            download_expiry=datetime.utcnow() + timedelta(days=30)
        )
        db.session.add(test_order_detail)
        db.session.commit()
        print('Order creation successful')
        
        # Test order retrieval
        order = Order.query.filter_by(payment_id='TEST123').first()
        if order and order.total_amount == 9.99:
            print('Order retrieval successful')
        else:
            print('Order retrieval failed')
            
        # Clean up
        db.session.delete(test_order_detail)
        db.session.delete(test_order)
        db.session.commit()
    except Exception as e:
        print(f'Order and payment test failed: {e}')
"
echo "Order and payment system test complete"
echo ""

# Test discount system
echo "Testing discount system..."
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, Discount
from flask import Flask
from datetime import datetime, timedelta
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Create test discount
        test_discount = Discount.query.filter_by(code='TEST10').first()
        if test_discount:
            db.session.delete(test_discount)
            db.session.commit()
            
        new_discount = Discount(
            code='TEST10',
            type='percentage',
            value=10,
            start_date=datetime.utcnow() - timedelta(days=1),
            end_date=datetime.utcnow() + timedelta(days=30),
            min_purchase=0,
            max_uses=100,
            current_uses=0,
            is_active=True
        )
        db.session.add(new_discount)
        db.session.commit()
        print('Discount creation successful')
        
        # Test discount retrieval
        discount = Discount.query.filter_by(code='TEST10').first()
        if discount and discount.value == 10:
            print('Discount retrieval successful')
        else:
            print('Discount retrieval failed')
            
        # Clean up
        db.session.delete(discount)
        db.session.commit()
    except Exception as e:
        print(f'Discount system test failed: {e}')
"
echo "Discount system test complete"
echo ""

# Test review system
echo "Testing review system..."
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, User, Product, Category, Review
from flask import Flask
from datetime import datetime
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Create test user
        test_user = User.query.filter_by(email='test@example.com').first()
        if not test_user:
            test_user = User(
                username='testuser',
                email='test@example.com',
                first_name='Test',
                last_name='User',
                is_active=True
            )
            test_user.set_password('password123')
            db.session.add(test_user)
            db.session.commit()
        
        # Create test category
        test_category = Category.query.filter_by(name='Test Category').first()
        if not test_category:
            test_category = Category(name='Test Category', description='Test Category Description')
            db.session.add(test_category)
            db.session.commit()
        
        # Create test product
        test_product = Product.query.filter_by(name='Test Product').first()
        if not test_product:
            test_product = Product(
                name='Test Product',
                description='Test Product Description',
                price=9.99,
                category_id=test_category.id,
                is_active=True,
                file_path='static/uploads/test.txt',
                file_size=1024,
                file_type='txt'
            )
            db.session.add(test_product)
            db.session.commit()
        
        # Create test review
        test_review = Review.query.filter_by(
            product_id=test_product.id,
            user_id=test_user.id
        ).first()
        if test_review:
            db.session.delete(test_review)
            db.session.commit()
            
        new_review = Review(
            product_id=test_product.id,
            user_id=test_user.id,
            rating=5,
            comment='Great product!',
            created_at=datetime.utcnow(),
            is_approved=True
        )
        db.session.add(new_review)
        db.session.commit()
        print('Review creation successful')
        
        # Test review retrieval
        review = Review.query.filter_by(
            product_id=test_product.id,
            user_id=test_user.id
        ).first()
        if review and review.rating == 5:
            print('Review retrieval successful')
        else:
            print('Review retrieval failed')
            
        # Clean up
        db.session.delete(review)
        db.session.commit()
    except Exception as e:
        print(f'Review system test failed: {e}')
"
echo "Review system test complete"
echo ""

# Test loyalty program
echo "Testing loyalty program..."
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, User
from flask import Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Create test user
        test_user = User.query.filter_by(email='test@example.com').first()
        if not test_user:
            test_user = User(
                username='testuser',
                email='test@example.com',
                first_name='Test',
                last_name='User',
                is_active=True,
                loyalty_points=0
            )
            test_user.set_password('password123')
            db.session.add(test_user)
            db.session.commit()
        
        # Add loyalty points
        test_user.loyalty_points = 100
        db.session.commit()
        print('Loyalty points addition successful')
        
        # Test loyalty points retrieval
        user = User.query.filter_by(email='test@example.com').first()
        if user and user.loyalty_points == 100:
            print('Loyalty points retrieval successful')
        else:
            print('Loyalty points retrieval failed')
            
        # Reset loyalty points
        test_user.loyalty_points = 0
        db.session.commit()
    except Exception as e:
        print(f'Loyalty program test failed: {e}')
"
echo "Loyalty program test complete"
echo ""

# Test secure download system
echo "Testing secure download system..."
echo "Note: This test only verifies the route logic, not actual file downloads"
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, User, Product, Category, Order, OrderDetail
from flask import Flask
from datetime import datetime, timedelta
import os
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Create test user
        test_user = User.query.filter_by(email='test@example.com').first()
        if not test_user:
            test_user = User(
                username='testuser',
                email='test@example.com',
                first_name='Test',
                last_name='User',
                is_active=True
            )
            test_user.set_password('password123')
            db.session.add(test_user)
            db.session.commit()
        
        # Create test category
        test_category = Category.query.filter_by(name='Test Category').first()
        if not test_category:
            test_category = Category(name='Test Category', description='Test Category Description')
            db.session.add(test_category)
            db.session.commit()
        
        # Create test product with test file
        test_product = Product.query.filter_by(name='Test Product').first()
        if not test_product:
            # Create test file
            os.makedirs('src/static/uploads', exist_ok=True)
            with open('src/static/uploads/test.txt', 'w') as f:
                f.write('This is a test file')
            
            test_product = Product(
                name='Test Product',
                description='Test Product Description',
                price=9.99,
                category_id=test_category.id,
                is_active=True,
                file_path='static/uploads/test.txt',
                file_size=os.path.getsize('src/static/uploads/test.txt'),
                file_type='txt'
            )
            db.session.add(test_product)
            db.session.commit()
        
        # Create test order
        test_order = Order(
            user_id=test_user.id,
            total_amount=9.99,
            payment_status='completed',
            payment_method='credit_card',
            payment_id='TEST123',
            created_at=datetime.utcnow(),
            discount_applied=0,
            loyalty_points_used=0,
            loyalty_points_earned=10
        )
        db.session.add(test_order)
        db.session.flush()
        
        # Create test order detail
        test_order_detail = OrderDetail(
            order_id=test_order.id,
            product_id=test_product.id,
            price=9.99,
            download_status='not_downloaded',
            download_count=0,
            download_expiry=datetime.utcnow() + timedelta(days=30)
        )
        db.session.add(test_order_detail)
        db.session.commit()
        print('Download test setup successful')
        
        # Simulate download
        test_order_detail.download_count += 1
        test_order_detail.download_status = 'downloaded'
        db.session.commit()
        
        # Verify download count
        order_detail = OrderDetail.query.get(test_order_detail.id)
        if order_detail and order_detail.download_count == 1:
            print('Download tracking successful')
        else:
            print('Download tracking failed')
            
        # Clean up
        db.session.delete(test_order_detail)
        db.session.delete(test_order)
        db.session.commit()
    except Exception as e:
        print(f'Secure download test failed: {e}')
"
echo "Secure download system test complete"
echo ""

# Test admin functionality
echo "Testing admin functionality..."
python3 -c "
import sys
sys.path.insert(0, '/home/ubuntu/digital_store')
from src.models.models import db, User
from flask import Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost:3306/mydb'
db.init_app(app)
with app.app_context():
    try:
        # Create test admin
        test_admin = User.query.filter_by(email='admin@example.com').first()
        if test_admin:
            db.session.delete(test_admin)
            db.session.commit()
            
        new_admin = User(
            username='testadmin',
            email='admin@example.com',
            first_name='Test',
            last_name='Admin',
            is_active=True,
            is_admin=True
        )
        new_admin.set_password('admin123')
        db.session.add(new_admin)
        db.session.commit()
        print('Admin creation successful')
        
        # Test admin retrieval
        admin = User.query.filter_by(email='admin@example.com').first()
        if admin and admin.is_admin:
            print('Admin retrieval successful')
        else:
            print('Admin retrieval failed')
            
        # Clean up
        db.session.delete(admin)
        db.session.commit()
    except Exception as e:
        print(f'Admin functionality test failed: {e}')
"
echo "Admin functionality test complete"
echo ""

echo "=== All tests completed ==="
echo "Test results saved to /home/ubuntu/digital_store_project/test_results"
echo ""

# Deactivate virtual environment
deactivate
