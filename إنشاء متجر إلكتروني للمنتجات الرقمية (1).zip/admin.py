from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from src.models.models import db, User, Product, Category, Order, OrderDetail, Review, Discount
from src.routes.auth import admin_required
import os
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import json

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/')
@admin_required
def dashboard():
    # Get statistics for dashboard
    total_products = Product.query.count()
    total_users = User.query.filter_by(is_admin=False).count()
    total_orders = Order.query.count()
    
    # Get recent orders
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    
    # Calculate total revenue
    total_revenue = db.session.query(db.func.sum(Order.total_amount)).filter_by(payment_status='completed').scalar() or 0
    
    # Get top selling products
    top_products = Product.query.order_by(Product.download_count.desc()).limit(5).all()
    
    # Get pending reviews
    pending_reviews = Review.query.filter_by(is_approved=False).count()
    
    return render_template('admin/dashboard.html',
                          total_products=total_products,
                          total_users=total_users,
                          total_orders=total_orders,
                          total_revenue=total_revenue,
                          recent_orders=recent_orders,
                          top_products=top_products,
                          pending_reviews=pending_reviews)

# Product Management
@admin_bp.route('/products')
@admin_required
def products():
    products = Product.query.all()
    return render_template('admin/products/index.html', products=products)

@admin_bp.route('/products/create', methods=['GET', 'POST'])
@admin_required
def create_product():
    categories = Category.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        price = request.form.get('price', type=float)
        category_id = request.form.get('category_id', type=int)
        is_featured = 'is_featured' in request.form
        
        if not name or not price or not category_id:
            flash('جميع الحقول المطلوبة يجب ملؤها', 'danger')
            return render_template('admin/products/create.html', categories=categories)
        
        # Handle file uploads
        digital_file = request.files.get('digital_file')
        thumbnail = request.files.get('thumbnail')
        
        if not digital_file:
            flash('يجب تحميل الملف الرقمي', 'danger')
            return render_template('admin/products/create.html', categories=categories)
        
        # Save digital file
        digital_filename = secure_filename(digital_file.filename)
        digital_path = os.path.join('static', 'uploads', 'products', digital_filename)
        os.makedirs(os.path.dirname(os.path.join('src', digital_path)), exist_ok=True)
        digital_file.save(os.path.join('src', digital_path))
        
        # Save thumbnail if provided
        thumbnail_path = None
        if thumbnail and thumbnail.filename:
            thumbnail_filename = secure_filename(thumbnail.filename)
            thumbnail_path = os.path.join('static', 'uploads', 'thumbnails', thumbnail_filename)
            os.makedirs(os.path.dirname(os.path.join('src', thumbnail_path)), exist_ok=True)
            thumbnail.save(os.path.join('src', thumbnail_path))
        
        # Handle preview images
        preview_images = []
        for i in range(5):  # Allow up to 5 preview images
            preview_file = request.files.get(f'preview_image_{i}')
            if preview_file and preview_file.filename:
                preview_filename = secure_filename(preview_file.filename)
                preview_path = os.path.join('static', 'uploads', 'previews', preview_filename)
                os.makedirs(os.path.dirname(os.path.join('src', preview_path)), exist_ok=True)
                preview_file.save(os.path.join('src', preview_path))
                preview_images.append(preview_path)
        
        # Create new product
        new_product = Product(
            name=name,
            description=description,
            price=price,
            category_id=category_id,
            is_featured=is_featured,
            is_active=True,
            thumbnail=thumbnail_path,
            preview_images=json.dumps(preview_images) if preview_images else None,
            file_path=digital_path,
            file_size=os.path.getsize(os.path.join('src', digital_path)),
            file_type=os.path.splitext(digital_filename)[1][1:].lower()
        )
        
        try:
            db.session.add(new_product)
            db.session.commit()
            flash('تم إنشاء المنتج بنجاح', 'success')
            return redirect(url_for('admin.products'))
        except Exception as e:
            db.session.rollback()
            flash(f'حدث خطأ أثناء إنشاء المنتج: {str(e)}', 'danger')
    
    return render_template('admin/products/create.html', categories=categories)

@admin_bp.route('/products/<int:product_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    categories = Category.query.all()
    
    if request.method == 'POST':
        product.name = request.form.get('name')
        product.description = request.form.get('description')
        product.price = request.form.get('price', type=float)
        product.category_id = request.form.get('category_id', type=int)
        product.is_featured = 'is_featured' in request.form
        product.is_active = 'is_active' in request.form
        
        # Handle file uploads if provided
        digital_file = request.files.get('digital_file')
        if digital_file and digital_file.filename:
            # Remove old file if exists
            if product.file_path and os.path.exists(os.path.join('src', product.file_path)):
                os.remove(os.path.join('src', product.file_path))
            
            # Save new file
            digital_filename = secure_filename(digital_file.filename)
            digital_path = os.path.join('static', 'uploads', 'products', digital_filename)
            os.makedirs(os.path.dirname(os.path.join('src', digital_path)), exist_ok=True)
            digital_file.save(os.path.join('src', digital_path))
            
            product.file_path = digital_path
            product.file_size = os.path.getsize(os.path.join('src', digital_path))
            product.file_type = os.path.splitext(digital_filename)[1][1:].lower()
        
        # Handle thumbnail if provided
        thumbnail = request.files.get('thumbnail')
        if thumbnail and thumbnail.filename:
            # Remove old thumbnail if exists
            if product.thumbnail and os.path.exists(os.path.join('src', product.thumbnail)):
                os.remove(os.path.join('src', product.thumbnail))
            
            # Save new thumbnail
            thumbnail_filename = secure_filename(thumbnail.filename)
            thumbnail_path = os.path.join('static', 'uploads', 'thumbnails', thumbnail_filename)
            os.makedirs(os.path.dirname(os.path.join('src', thumbnail_path)), exist_ok=True)
            thumbnail.save(os.path.join('src', thumbnail_path))
            
            product.thumbnail = thumbnail_path
        
        # Update preview images if provided
        preview_images = []
        if product.preview_images:
            try:
                preview_images = json.loads(product.preview_images)
            except:
                preview_images = []
        
        for i in range(5):  # Allow up to 5 preview images
            preview_file = request.files.get(f'preview_image_{i}')
            if preview_file and preview_file.filename:
                # Save new preview image
                preview_filename = secure_filename(preview_file.filename)
                preview_path = os.path.join('static', 'uploads', 'previews', preview_filename)
                os.makedirs(os.path.dirname(os.path.join('src', preview_path)), exist_ok=True)
                preview_file.save(os.path.join('src', preview_path))
                
                # Add to preview images list
                if i < len(preview_images):
                    # Replace existing preview
                    old_preview = preview_images[i]
                    if old_preview and os.path.exists(os.path.join('src', old_preview)):
                        os.remove(os.path.join('src', old_preview))
                    preview_images[i] = preview_path
                else:
                    # Add new preview
                    preview_images.append(preview_path)
        
        product.preview_images = json.dumps(preview_images) if preview_images else None
        product.updated_at = datetime.utcnow()
        
        try:
            db.session.commit()
            flash('تم تحديث المنتج بنجاح', 'success')
            return redirect(url_for('admin.products'))
        except Exception as e:
            db.session.rollback()
            flash(f'حدث خطأ أثناء تحديث المنتج: {str(e)}', 'danger')
    
    return render_template('admin/products/edit.html', product=product, categories=categories)

@admin_bp.route('/products/<int:product_id>/delete', methods=['POST'])
@admin_required
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    
    try:
        # Delete associated files
        if product.file_path and os.path.exists(os.path.join('src', product.file_path)):
            os.remove(os.path.join('src', product.file_path))
        
        if product.thumbnail and os.path.exists(os.path.join('src', product.thumbnail)):
            os.remove(os.path.join('src', product.thumbnail))
        
        if product.preview_images:
            try:
                preview_images = json.loads(product.preview_images)
                for preview in preview_images:
                    if preview and os.path.exists(os.path.join('src', preview)):
                        os.remove(os.path.join('src', preview))
            except:
                pass
        
        db.session.delete(product)
        db.session.commit()
        flash('تم حذف المنتج بنجاح', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'حدث خطأ أثناء حذف المنتج: {str(e)}', 'danger')
    
    return redirect(url_for('admin.products'))

# Category Management
@admin_bp.route('/categories')
@admin_required
def categories():
    categories = Category.query.all()
    return render_template('admin/categories/index.html', categories=categories)

@admin_bp.route('/categories/create', methods=['GET', 'POST'])
@admin_required
def create_category():
    categories = Category.query.all()  # For parent category selection
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        parent_id = request.form.get('parent_id', type=int)
        
        if not name:
            flash('اسم الفئة مطلوب', 'danger')
            return render_template('admin/categories/create.html', categories=categories)
        
        # Handle image upload
        image = request.files.get('image')
        image_path = None
        if image and image.filename:
            image_filename = secure_filename(image.filename)
            image_path = os.path.join('static', 'uploads', 'categories', image_filename)
            os.makedirs(os.path.dirname(os.path.join('src', image_path)), exist_ok=True)
            image.save(os.path.join('src', image_path))
        
        # Create new category
        new_category = Category(
            name=name,
            description=description,
            parent_id=parent_id if parent_id else None,
            image=image_path
        )
        
        try:
            db.session.add(new_category)
            db.session.commit()
            flash('تم إنشاء الفئة بنجاح', 'success')
            return redirect(url_for('admin.categories'))
        except Exception as e:
            db.session.rollback()
            flash(f'حدث خطأ أثناء إنشاء الفئة: {str(e)}', 'danger')
    
    return render_template('admin/categories/create.html', categories=categories)

# User Management
@admin_bp.route('/users')
@admin_required
def users():
    users = User.query.all()
    return render_template('admin/users/index.html', users=users)

@admin_bp.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_user(user_id):
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        user.username = request.form.get('username')
        user.email = request.form.get('email')
        user.first_name = request.form.get('first_name')
        user.last_name = request.form.get('last_name')
        user.is_active = 'is_active' in request.form
        user.is_admin = 'is_admin' in request.form
        user.loyalty_points = request.form.get('loyalty_points', type=int, default=0)
        
        # Handle password change if provided
        new_password = request.form.get('new_password')
        if new_password:
            user.set_password(new_password)
        
        try:
            db.session.commit()
            flash('تم تحديث المستخدم بنجاح', 'success')
            return redirect(url_for('admin.users'))
        except Exception as e:
            db.session.rollback()
            flash(f'حدث خطأ أثناء تحديث المستخدم: {str(e)}', 'danger')
    
    return render_template('admin/users/edit.html', user=user)

# Order Management
@admin_bp.route('/orders')
@admin_required
def orders():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin/orders/index.html', orders=orders)

@admin_bp.route('/orders/<int:order_id>')
@admin_required
def order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('admin/orders/detail.html', order=order)

# Review Management
@admin_bp.route('/reviews')
@admin_required
def reviews():
    reviews = Review.query.order_by(Review.created_at.desc()).all()
    return render_template('admin/reviews/index.html', reviews=reviews)

@admin_bp.route('/reviews/<int:review_id>/approve', methods=['POST'])
@admin_required
def approve_review(review_id):
    review = Review.query.get_or_404(review_id)
    review.is_approved = True
    
    try:
        db.session.commit()
        flash('تم اعتماد المراجعة بنجاح', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'حدث خطأ أثناء اعتماد المراجعة: {str(e)}', 'danger')
    
    return redirect(url_for('admin.reviews'))

@admin_bp.route('/reviews/<int:review_id>/delete', methods=['POST'])
@admin_required
def delete_review(review_id):
    review = Review.query.get_or_404(review_id)
    
    try:
        db.session.delete(review)
        db.session.commit()
        flash('تم حذف المراجعة بنجاح', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'حدث خطأ أثناء حذف المراجعة: {str(e)}', 'danger')
    
    return redirect(url_for('admin.reviews'))

# Discount Management
@admin_bp.route('/discounts')
@admin_required
def discounts():
    discounts = Discount.query.all()
    return render_template('admin/discounts/index.html', discounts=discounts)

@admin_bp.route('/discounts/create', methods=['GET', 'POST'])
@admin_required
def create_discount():
    if request.method == 'POST':
        code = request.form.get('code')
        discount_type = request.form.get('type')
        value = request.form.get('value', type=float)
        min_purchase = request.form.get('min_purchase', type=float, default=0)
        max_uses = request.form.get('max_uses', type=int)
        
        # Parse dates
        start_date_str = request.form.get('start_date')
        end_date_str = request.form.get('end_date')
        
        try:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
        except ValueError:
            flash('صيغة التاريخ غير صحيحة', 'danger')
            return render_template('admin/discounts/create.html')
        
        if not code or not discount_type or not value:
            flash('جميع الحقول المطلوبة يجب ملؤها', 'danger')
            return render_template('admin/discounts/create.html')
        
        # Check if code already exists
        existing_discount = Discount.query.filter_by(code=code).first()
        if existing_discount:
            flash('رمز الخصم موجود بالفعل', 'danger')
            return render_template('admin/discounts/create.html')
        
        # Create new discount
        new_discount = Discount(
            code=code,
            type=discount_type,
            value=value,
            start_date=start_date,
            end_date=end_date,
            min_purchase=min_purchase,
            max_uses=max_uses,
            current_uses=0,
            is_active=True
        )
        
        try:
            db.session.add(new_discount)
            db.session.commit()
            flash('تم إنشاء الخصم بنجاح', 'success')
            return redirect(url_for('admin.discounts'))
        except Exception as e:
            db.session.rollback()
            flash(f'حدث خطأ أثناء إنشاء الخصم: {str(e)}', 'danger')
    
    return render_template('admin/discounts/create.html')

@admin_bp.route('/discounts/<int:discount_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_discount(discount_id):
    discount = Discount.query.get_or_404(discount_id)
    
    if request.method == 'POST':
        discount.code = request.form.get('code')
        discount.type = request.form.get('type')
        discount.value = request.form.get('value', type=float)
        discount.min_purchase = request.form.get('min_purchase', type=float, default=0)
        discount.max_uses = request.form.get('max_uses', type=int)
        discount.is_active = 'is_active' in request.form
        
        # Parse dates
        start_date_str = request.form.get('start_date')
        end_date_str = request.form.get('end_date')
        
        try:
            discount.start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
            discount.end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
        except ValueError:
            flash('صيغة التاريخ غير صحيحة', 'danger')
            return render_template('admin/discounts/edit.html', discount=discount)
        
        try:
            db.session.commit()
            flash('تم تحديث الخصم بنجاح', 'success')
            return redirect(url_for('admin.discounts'))
        except Exception as e:
            db.session.rollback()
            flash(f'حدث خطأ أثناء تحديث الخصم: {str(e)}', 'danger')
    
    return render_template('admin/discounts/edit.html', discount=discount)
