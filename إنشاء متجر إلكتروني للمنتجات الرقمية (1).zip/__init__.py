from src.models.models import db, User, Category, Product, Review, Order, OrderDetail, Discount
